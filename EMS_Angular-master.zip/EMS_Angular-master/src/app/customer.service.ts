import { Injectable } from '@angular/core';
import { HttpHeaders ,HttpClient} from '@angular/common/http';
import { UserDetails } from './util/userDetails.model';
import { Observable } from 'rxjs';
import {LocalStorageService} from 'ngx-webstorage';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {
acc_id;
  constructor(private http:HttpClient,private LocalStorageService:LocalStorageService) {
   this.acc_id=this.LocalStorageService.retrieve("custid");
   alert(this.acc_id);
   }
  getAllCustomerList(){
    let CustomerList=[
    ];
  return CustomerList;
  }



  private url: string ='http://192.168.0.149:3759/addCustomer';


//   getEmployees():Observable<IEmployee[]>{
//     return this.http.get<IEmployee[]>(this.url)
//     .pipe(tap(data => alert(JSON.stringify(data))) , catchError(this.errorHandler))
// }
// errorHandler(error: HttpErrorResponse){
// return observableThrowError(error.message || "Server Error");
// }

addUser(user:UserDetails):Observable<UserDetails>
{
  alert("control reached to method of service");
  alert(JSON.stringify(user));
  return this.http.post<UserDetails>(this.url,user,{
   headers: new HttpHeaders({
  'Content-Type':'application/json'
    })
   }); 
}


getBalance()
{
  return this.http.get("http://192.168.0.149:3759/checkBalance/"+this.acc_id);
}

}
