import { Time } from '@angular/common';
import {Passenger} from './Passenger';

export class TransferStatus
{
    //booking table
    bookingId: number;
	noOfPassengers: number;
	classType: string;
	totalFare: number;
    arrivalTime: Time;
	departureTime: Time;
	airLine: string;
	depCity: string;
	arrCity: string;
	depDate: Date;
    arrDate: Date;
    passengers: Passenger[] = [];

}