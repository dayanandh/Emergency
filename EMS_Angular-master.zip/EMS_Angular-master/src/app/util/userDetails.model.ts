export class UserDetails
{
username:string;
name:string;
emailId:string;
mobileNo:string;
password:string;
} 