export class AccountDetails{

   source: string;
   destination: string;
   traveldate: Date;
}