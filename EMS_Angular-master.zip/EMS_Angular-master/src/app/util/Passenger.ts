export class Passenger
{
    passengername: string;
    passengerage: number;
    passengergender: String;

    constructor(passengername,passengerage,passengergender) {
        this.passengername = passengername;
        this.passengerage = passengerage;
        this.passengergender = passengergender;
    }
}