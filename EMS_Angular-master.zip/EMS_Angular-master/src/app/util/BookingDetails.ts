import {Passenger} from './Passenger';

export class BookingDetails{
    classType: string;
    passengers: Passenger[] = [];
}