import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SourceDestinationComponent } from './source-destination.component';

describe('SourceDestinationComponent', () => {
  let component: SourceDestinationComponent;
  let fixture: ComponentFixture<SourceDestinationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SourceDestinationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SourceDestinationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
