import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-source-destination',
  templateUrl: './source-destination.component.html',
  styleUrls: ['./source-destination.component.css']
})
export class SourceDestinationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
