import { Component } from '@angular/core';
import { ARSService } from './app.service';
import { Flight } from './flight';
import { DatePipe } from '@angular/common'
@Component({
    selector: 'book-app',
    templateUrl: `./app.bookcomponent.html`,
    styleUrls: ['./app.bookcomponent.css'],
    providers: [ARSService, DatePipe]
})
export class BookComponent {
    constructor(private service: ARSService, public datepipe: DatePipe) {
    }

    scity: string;
    dcity: string;
    date: string;
    flights: Flight[];
    way: boolean = true;
    dup_scity: string;
    dup_date: string;
    dup_dcity: string;
    fare:number;
    
    onShow(): void {
        this.dup_scity = this.scity;
        this.dup_date = this.date;
        this.dup_dcity = this.dcity;
        this.way = false;
        this.service.bookShow(this.scity, this.dcity, this.date).subscribe((flightData: Flight[]) => this.flights = flightData,
            (error) => {
                console.error(error);
            }
        );
        
    }

}