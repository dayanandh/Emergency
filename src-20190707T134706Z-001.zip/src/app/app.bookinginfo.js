"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var app_service_1 = require("./app.service");
var BookingInfoComponent = (function () {
    function BookingInfoComponent(ac, router, service) {
        this.ac = ac;
        this.router = router;
        this.service = service;
        this.types = ['Economy', 'Business'];
        this.bookinfo = {};
    }
    BookingInfoComponent.prototype.ngOnInit = function () {
        this.bookinfo.flightno = this.ac.snapshot.params['flightno'];
        this.bookinfo.src_city = this.ac.snapshot.params['srcity'];
        this.bookinfo.dest_city = this.ac.snapshot.params['descity'];
        this.firstfare = this.ac.snapshot.params['firstfare'];
        this.busfare = this.ac.snapshot.params['busfare'];
        this.bookinfo.booking_date = new Date();
        this.bookinfo.booking_id = this.getRandomInt(1000, 5000);
    };
    BookingInfoComponent.prototype.bookTicket = function () {
        if (this.class_type == "Economy") {
            this.bookinfo.total_fare = this.firstfare * this.no_of_passengers;
        }
        else if (this.class_type == "Business") {
            this.bookinfo.total_fare = this.busfare * this.no_of_passengers;
        }
        var retVal = confirm("Total Fare is" + this.total_fare + " Do you want to continue ?");
        if (retVal == true) {
            console.log("User wants to continue!");
            this.service.addBookinfo(this.bookinfo).subscribe(function (error) {
                console.error(error);
            });
            this.router.navigate(['confirmbook']);
        }
        else {
            console.log("User does not want to continue!");
        }
    };
    BookingInfoComponent.prototype.getRandomInt = function (min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    };
    return BookingInfoComponent;
}());
BookingInfoComponent = __decorate([
    core_1.Component({
        selector: 'booking-app',
        templateUrl: "./app.bookinginfo.html",
        styleUrls: ['./app.bookinginfo.css'],
        providers: [app_service_1.ARSService]
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute, router_1.Router, app_service_1.ARSService])
], BookingInfoComponent);
exports.BookingInfoComponent = BookingInfoComponent;
