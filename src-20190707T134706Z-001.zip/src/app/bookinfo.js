"use strict";
var BookInfo = (function () {
    function BookInfo() {
    }
    return BookInfo;
}());
exports.BookInfo = BookInfo;
