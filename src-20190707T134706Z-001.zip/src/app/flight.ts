export class Flight {

    flightno: string;
    airLine: string;
    dep_city: string;
    arr_city: string;
    dep_date: string;
    arr_date: string;
    dep_time: string;
    arr_time: string;
    firstseats: number;
    firstseatfare: number;
    busseats: number;
    busseatsfare: number;
}