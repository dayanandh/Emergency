import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { Routes,RouterModule} from '@angular/router';
import { AppComponent }  from './app.component';
import { HttpModule } from '@angular/http';
import { LoginComponent } from './app.logincomponent';
import { HomeComponent } from './app.homecomponent';
import { BookComponent } from './app.bookcomponent';
import { BookingInfoComponent } from './app.bookinginfo';
import { ConfirmedComponent } from './app.confirmedbook'
const appRouter:Routes=[
  {path:'login',component: LoginComponent},
  {path:'home',component: HomeComponent},
  {path:'book',component: BookComponent },
  {path:'bookinfo/:flightno/:srcity/:descity/:firstfare/:busfare',component: BookingInfoComponent },
  {path:'confirmbook',component: ConfirmedComponent }
]
@NgModule({
  imports:      [ BrowserModule, FormsModule,HttpModule,RouterModule.forRoot(appRouter)],
  declarations: [ AppComponent ,LoginComponent,HomeComponent, BookComponent, BookingInfoComponent,ConfirmedComponent],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
