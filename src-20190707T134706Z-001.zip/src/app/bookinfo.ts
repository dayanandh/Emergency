export class BookInfo{
      booking_id:number;
      no_of_passengers:number;
      class_type:string;
      total_fare:number;
      seat_number:number;
      creditcard_info:any;
      src_city:string;
      dest_city:string;
      flightno:string;
      cust_email:string;
      booking_date:Date;
      customer_names:string;
}

