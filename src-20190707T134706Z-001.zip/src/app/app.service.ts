import { Observable } from 'rxjs/Observable';
import { User } from './user';
import { Http, Response,Headers, RequestOptions} from '@angular/http';
import { Injectable } from '@angular/core';
import { Flight } from './flight';
import { BookInfo } from './bookinfo'

import "rxjs/add/operator/map"
import "rxjs/add/operator/catch"

@Injectable()
export class ARSService{

    constructor(private http: Http) { }

    getUser(data: number): Observable<User[]> {
        console.log("IN Service: ",data)
        return this.http
            .get('http://localhost:8082/SpringARS/rest/user/search/' + data)
            .map((response: Response) => <User[]>response.json())
            .catch(this.handleError);
    }
   
    bookShow(scity: string,dcity:string,date:string): Observable<Flight[]> {
        console.log("IN Service: ",scity,dcity,date)
        return this.http
            .get('http://localhost:8082/SpringARS/rest/flight/search/' + scity +'/'+ dcity +'/' +date)
            .map((response: Response) => <Flight[]>response.json())
            .catch(this.handleError);
    }
    addBookinfo(data:BookInfo): Observable<BookInfo[]> {
        let bookData=JSON.stringify(data);
        let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: cpHeaders });
        
        return this.http
            .post('http://localhost:8082/SpringARS/rest/book/create/',bookData,options)
            .map((success => success.status))
            .catch(this.handleError);
        }

    handleError(error: Response) {
        console.error(error);
        return Observable.throw(error);
    }
}