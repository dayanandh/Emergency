"use strict";
var User = (function () {
    function User() {
    }
    User.prototype.getmobile_no = function () {
        return this.mobile_no;
    };
    User.prototype.setmobile_no = function (v) {
        this.mobile_no = v;
    };
    return User;
}());
exports.User = User;
