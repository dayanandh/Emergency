import { Component, OnInit } from '@angular/core';
import { Router,Params, ActivatedRoute } from '@angular/router';
import { BookInfo } from './bookinfo'
import { ARSService } from './app.service';

@Component({
  selector: 'booking-app',
  templateUrl: `./app.bookinginfo.html`,
  styleUrls: ['./app.bookinginfo.css'],
  providers: [ARSService]
})
export class BookingInfoComponent implements OnInit {

  constructor(private ac: ActivatedRoute,private router:Router,private service: ARSService) { }

  ngOnInit() {
    this.bookinfo.flightno = this.ac.snapshot.params['flightno'];
    this.bookinfo.src_city = this.ac.snapshot.params['srcity'];
    this.bookinfo.dest_city = this.ac.snapshot.params['descity'];
    this.firstfare = this.ac.snapshot.params['firstfare'];
    this.busfare = this.ac.snapshot.params['busfare']; 
    this.bookinfo.booking_date= new Date();
    this.bookinfo.booking_id=this.getRandomInt(1000,5000);
  }

  firstfare:number;
  busfare:number;

  flightno : string;
  src_city:string;
  dest_city:string;
  total_fare:number;
  cust_email: string;
  class_type: string;
  no_of_passengers: number;
  customer_names: string;
  types = ['Economy', 'Business'];
  booking_date: Date ;
  booking_id:number;
  bookinfo:any={};

  bookTicket(): void {
    if(this.class_type=="Economy"){
     this.bookinfo.total_fare= this.firstfare * this.no_of_passengers;
    }
    else if(this.class_type=="Business"){
      this.bookinfo.total_fare= this.busfare * this.no_of_passengers;
    }
    var retVal = confirm("Total Fare is"+this.total_fare+" Do you want to continue ?");
    if (retVal == true) {
      console.log("User wants to continue!");
      this.service.addBookinfo(this.bookinfo).subscribe(
            (error)=>{
                    console.error(error);
            }    
            );
    this.router.navigate(['confirmbook']);
    } else {
      console.log("User does not want to continue!");
    }
  }

  getRandomInt(min: number, max: number): any {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }


}