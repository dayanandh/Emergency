import { Component } from '@angular/core';

@Component({
    selector: 'home-app',
    templateUrl: `./app.homecomponent.html`,
  })
export class HomeComponent{

}