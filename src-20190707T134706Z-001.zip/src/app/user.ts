export class User {
    username: String;
    password: String;
    role: string;
    mobile_no: string;
    
    public getmobile_no() : string {
        return this.mobile_no;
    }
    public setmobile_no(v : string) {
        this.mobile_no = v;
    }
   
}