import { Component } from '@angular/core';
import { ARSService } from './app.service';
import { User } from './user'
import {Router} from '@angular/router'

@Component({
  selector: 'login-app',
  templateUrl: `./app.logincomponent.html`,
  styleUrls: ['./app.logincomponent.css'],
  providers: [ARSService]
})
export class LoginComponent {
  constructor(private service: ARSService,private router:Router) {
  }

  uname: any;
  pword: string;
  model:any={};
  
  onSubmit(): void {
    this.service.getUser(this.uname).subscribe((userData:User[]) => this.model = userData,
      (error) => {
         console.error(error);
      },
      ()=>{ this.router.navigate(['home']);}
    );
  }
 
}
