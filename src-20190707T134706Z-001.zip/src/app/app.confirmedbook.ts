import { Component } from '@angular/core';
@Component({
    selector: 'confirm-app',
    templateUrl: `./app.confirmedbook.html`
  })

export class ConfirmedComponent{

}